<template>
  <div class="text-neutral-400">
    <span>Star on</span>
    <a href="https://xwbot.xaloweb.com" target="_blank" class="text-blue-500">
      XWBOT
    </a>
  </div>
</template>
