import { computed } from 'vue'
import { viVN,enUS } from 'naive-ui'
import { useAppStore } from '@/store'
import { setLocale } from '@/locales'

export function useLanguage() {
  const appStore = useAppStore()

  const language = computed(() => {
    switch (appStore.language) {
      case 'en-US':
        setLocale('en-US')
        return enUS
      case 'vi-VN':
        setLocale('vi-VN')
        return viVN
      default:
        setLocale('vi-VN')
        return enUS
    }
  })

  return { language }
}
